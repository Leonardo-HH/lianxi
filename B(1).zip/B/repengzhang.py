# -*- coding: utf-8 -*-
"""
Created on Mon May 19 11:02:36 2025

@author: fuche
"""


import os
import torch
import torch.autograd as autograd
import torch.nn as nn
import matplotlib.pyplot as plt
import numpy as np
import time
import scipy.io
import math
import scipy
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import matplotlib.pyplot as plt
import operator
from functools import reduce
from functools import partial
from timeit import default_timer
from torch.autograd import Variable
import os
import csv
from torch.autograd.functional import jacobian

# 设备配置：使用GPU（如果可用），否则使用CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)

# 加载MATLAB格式的数据文件
path = r'C:\Users\fuche\Downloads\Package_Open_Hole.mat'

# 计算y关于x的导数（自动微分）
def derivee(y,x):
  return autograd.grad(y,x,torch.ones_like(y),retain_graph=True,create_graph=True)[0]

# 沿最后一个维度求和并保持维度
def som(s):
  return torch.sum(s,dim=-1,keepdim=True)

# 离线数据处理类：负责加载和准备有限元分析所需的几何和特征函数数据
class Offline:
    def __init__(self, path):
        Data = scipy.io.loadmat(path)
        # 欧几里得坐标
        coor = torch.tensor(Data['nodes'], dtype = torch.float32).to(device)
        self.X = coor[:,0:1].to(device)  # x坐标
        self.Y = coor[:,1:2].to(device)  # y坐标
        
        # LBO特征函数及其导数（用于谱方法）
        self.Phi = torch.tensor(Data['phi'], dtype = torch.float32).to(device)  # 特征函数值
        self.dPhi_dx = torch.tensor(Data['dphi_dx'], dtype = torch.float32).to(device)  # 特征函数对x的导数
        self.dPhi_dy = torch.tensor(Data['dphi_dy'], dtype = torch.float32).to(device)  # 特征函数对y的导数
        self.d2Phi_dx2 = torch.tensor(Data['d2phi_dx2'], dtype = torch.float32).to(device)  # 特征函数对x的二阶导数
        self.d2Phi_dy2 = torch.tensor(Data['d2phi_dy2'], dtype = torch.float32).to(device)  # 特征函数对y的二阶导数
        
        # 节点标签：区分边界节点和内部节点
        bc1_nodes = torch.tensor(Data['bc1_nodes'].astype(np.float32), dtype = torch.float32).to(device).squeeze()
        interior_nodes = torch.tensor(Data['interior_nodes'].astype(np.float32), dtype = torch.float32).to(device).squeeze()
        
        # 边界条件损失的配置点（索引调整为0-based）
        self.L_dbc = bc1_nodes - 1.0
        # PDE损失的配置点（索引调整为0-based）
        self.L_pde = interior_nodes - 1.0

    def forward(self, labels, n, **kwargs):
        """
        根据标签和参数选择特定的数据
        labels: 节点标签
        n: 特征数量
        kwargs: 控制返回哪些数据的标志
        """
        attribute_map = {'x': ('X', True),'y': ('Y', True),
                  'phi': ('Phi', False),'dphi_dx': ('dPhi_dx', False),'dphi_dy': ('dPhi_dy', False),
                  'd2phi_dx2': ('d2Phi_dx2', False),'d2phi_dy2': ('d2Phi_dy2', False)}
        output = []
        for key, (attr, default) in attribute_map.items():
            if kwargs.get(key, default):
                output.append(getattr(self, attr)[labels.int(), :n])
        return tuple(output)
    
# 在线训练类：负责定义损失函数和训练过程
class Online:
    def __init__(self, path, off, model):
        # 离线阶段的数据
        self.off = off
        # 解决方案模型
        self.model = model
        # 物理参数：杨氏模量和泊松比
        E, mu = 1.0, 0.3
        # 弹性矩阵（平面应力状态）
        Cons = E/(1-mu**2)*torch.tensor([[1,mu,0],[mu,1,0],[0,0,0.5*(1-mu)]]).to(device)
        self.c1,self.c2,self.c3 = Cons[0,0],Cons[0,1],Cons[2,2]  # 提取弹性常数

    def label_pde(self):
        """返回PDE损失计算的节点标签"""
        L_pde = self.off.L_pde
        return L_pde

    def Dbc_loss(self):
        """计算位移边界条件损失（Dirichlet边界条件）"""
        x, y, phi = self.off.forward(self.off.L_dbc, n_u, phi=True)
        ux, uy = self.model(x, y, phi)  # 模型预测的位移
        # 边界上位移应为0，计算均方误差损失
        dbc_loss = F.mse_loss(ux, torch.zeros_like(ux)) + F.mse_loss(uy, torch.zeros_like(uy))
        return dbc_loss

    def PDE_loss(self,label):
        """计算偏微分方程（PDE）残差损失"""
        # 获取节点的坐标和特征函数导数
        x, y, dphi_dx, dphi_dy, d2phi_dx2, d2phi_dy2 = self.off.forward(label, n_sigma, dphi_dx=True, dphi_dy=True, d2phi_dx2=True, d2phi_dy2=True)
        x.requires_grad = True
        y.requires_grad = True
        
        # 模型预测应力分量和辅助变量
        sigma_xx, sigma_xy, sigma_yx, sigma_yy, px, py = self.model.Fsigma(x,y,dphi_dx,dphi_dy)

        # 计算应力的偏导数（平衡方程的一部分）
        dsigmaxx_dx = derivee(sigma_xx,x) + som(px * d2phi_dx2)
        dsigmaxy_dy = derivee(sigma_xy,y) + som(px * d2phi_dy2)
        dsigmayx_dx = derivee(sigma_yx,x) + som(py * d2phi_dx2)
        dsigmayy_dy = derivee(sigma_yy,y) + som(py * d2phi_dy2)

        # 平衡方程：div(sigma) = 0
        pde_x = dsigmaxx_dx + dsigmaxy_dy
        pde_y = dsigmayx_dx + dsigmayy_dy

        # 计算PDE残差的均方误差损失
        pde_loss_x = F.mse_loss(pde_x, torch.zeros_like(pde_x))
        pde_loss_y = F.mse_loss(pde_y, torch.zeros_like(pde_y))

        return pde_loss_x + pde_loss_y

    def C_loss(self,label):
        """计算本构关系损失（应力-应变关系）"""
        # 获取节点的坐标和特征函数
        x, y, phi, dphi_dx, dphi_dy = self.off.forward(label, n_u, phi=True, dphi_dx=True, dphi_dy=True)
        x.requires_grad = True
        y.requires_grad = True
        phi.requires_grad = True

        # 模型预测位移
        ux, uy = self.model(x,y,phi)

        # 计算应变分量（位移的导数）
        epsilon_xx = derivee(ux,x) + som(derivee(ux,phi) * dphi_dx) + 0.1
        epsilon_xy = derivee(ux,y) + som(derivee(ux,phi) * dphi_dy)
        epsilon_yx = derivee(uy,x) + som(derivee(uy,phi) * dphi_dx)
        epsilon_yy = derivee(uy,y) + som(derivee(uy,phi) * dphi_dy) + 0.1

        # 根据本构关系（胡克定律）计算应力
        sigma_xx0 = self.c1*epsilon_xx + self.c2*epsilon_yy
        sigma_xy0 = self.c3*epsilon_xy + self.c3*epsilon_yx
        sigma_yx0 = self.c3*epsilon_xy + self.c3*epsilon_yx
        sigma_yy0 = self.c2*epsilon_xx + self.c1*epsilon_yy

        # 重新获取节点数据（使用不同的特征数量）
        x, y, phi, dphi_dx, dphi_dy = self.off.forward(label, n_sigma, phi=True, dphi_dx=True, dphi_dy=True)
        # 模型直接预测应力
        sigma_xx, sigma_xy, sigma_yx, sigma_yy, H1, H2 = self.model.Fsigma(x,y,dphi_dx,dphi_dy)

        # 计算本构关系损失：比较基于应变计算的应力和模型直接预测的应力
        loss_C = F.mse_loss(torch.cat((sigma_xx0,sigma_xy0,sigma_yx0,sigma_yy0),dim=-1), \
                    torch.cat((sigma_xx,sigma_xy,sigma_yx,sigma_yy),dim=-1))

        return loss_C
    
# 基于GELU激活函数的多层感知机
class MLP_gelu(nn.Module):
    def __init__(self,insize,outsize,width,layers):
        super().__init__()
        self.input_layer = nn.Linear(insize,width)  # 输入层
        self.hidden_layers = nn.ModuleList([])  # 隐藏层列表
        self.output_layer = nn.Linear(width,outsize)  # 输出层
        
        # 添加指定数量的隐藏层
        for i in range(layers):
          self.linear_layer = nn.Linear(width,width)
          self.hidden_layers.append(self.linear_layer)
        self.layers = layers

    def forward(self, x):
        # 使用GELU激活函数的前向传播
        layer_out = F.gelu(self.input_layer(x))
        for i in range(self.layers):
            layer_out = F.gelu(self.hidden_layers[i](layer_out))
        layer_out = self.output_layer(layer_out)
        return layer_out

# 基于物理信息神经网络的有限元模型
class Finite_PINN(nn.Module):
    def __init__(self, n_sigma, n_u):
        super(Finite_PINN, self).__init__()

        width = 128  # 隐藏层宽度
        # 用于预测应力相关参数的神经网络
        self.NN_H1 = MLP_gelu(2,n_sigma,width,4)  # 输入坐标，输出应力相关参数
        self.NN_H2 = MLP_gelu(2,n_sigma,width,4)  # 输入坐标，输出应力相关参数
        
        # 用于预测位移相关参数的神经网络
        self.NN_eu1 = MLP_gelu(2+n_u,1,width,4)  # 输入坐标和特征函数，输出位移相关参数
        self.NN_eu2 = MLP_gelu(2+n_u,1,width,4)  # 输入坐标和特征函数，输出位移相关参数

    def forward(self, x, y, u):
        """预测位移分量"""
        # 拼接输入特征
        v1 = self.NN_eu1(torch.cat((x,y,u),dim=-1))  # x方向位移
        v2 = self.NN_eu2(torch.cat((x,y,u),dim=-1))  # y方向位移

        return v1,v2

    def Fsigma(self, x, y, du_dx, du_dy):
        """预测应力分量"""
        # 基于坐标预测应力相关参数
        px = self.NN_H1(torch.cat((x,y),dim=-1))
        py = self.NN_H2(torch.cat((x,y),dim=-1))

        # 计算应力分量
        sig_xx, sig_xy = som(px * du_dx), som(px * du_dy)
        sig_yx, sig_yy = som(py * du_dx), som(py * du_dy)

        return sig_xx,sig_xy,sig_yx,sig_yy,px,py

# 模型参数配置
n_sigma = 4  # 应力相关特征数量
n_u = 4      # 位移相关特征数量

# 初始化模型和数据处理流程
OFF = Offline(path)  # 离线数据处理
model = Finite_PINN(n_sigma = n_sigma, n_u = n_u).to(device, dtype = torch.float32)  # 物理信息神经网络模型
ON = Online(path,OFF,model)  # 在线训练流程

# 准备训练数据
L_pde = ON.label_pde()
dataset = torch.utils.data.TensorDataset(L_pde,torch.zeros_like(L_pde))
trainset = torch.utils.data.DataLoader(dataset, batch_size=200, shuffle=True, drop_last=True)

# 优化器配置
optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
num_epochs = 100  # 训练轮数
csize = 4  # 块大小（在代码中未使用）

# 训练循环
for ep in range(num_epochs):
    model.train()
    t1 = default_timer()  # 记录开始时间
    bc_mse,pde_mse,c_mse = 0,0,0  # 初始化损失值
    ne = 0  # 批次计数器

    # 批次训练
    for l_pde, r_pde in trainset:

        ne += 1
        optimizer.zero_grad()  # 梯度清零

        # 计算三种损失
        dbc_loss = ON.Dbc_loss()  # 边界条件损失
        pde_loss = ON.PDE_loss(l_pde)  # PDE残差损失
        C_loss = ON.C_loss(l_pde)  # 本构关系损失

        # 总损失：三种损失之和
        Loss = dbc_loss + pde_loss + C_loss

        # 反向传播和优化
        Loss.backward()
        optimizer.step()

        # 累积损失值用于统计
        bc_mse += dbc_loss.item()
        pde_mse += pde_loss.item()
        c_mse += C_loss.item()

    # 计算平均损失
    bc_mse /= ne
    pde_mse /= ne
    c_mse /= ne

    t2 = default_timer()  # 记录结束时间

    # 打印训练进度
    print(f'Epoch:{ep+1}, Time:{t2-t1:.3g}s, BC Loss:{bc_mse:.3e}, PDE Loss:{pde_mse:.3e}, C Loss:{c_mse:.3e}')
model.eval()
X_plot, Y_plot, Phi_plot = OFF.X, OFF.Y, OFF.Phi[:,:n_u]
vx_plot, vy_plot = model(OFF.X, OFF.Y, OFF.Phi[:,:n_u])
vx_plot = vx_plot.squeeze().squeeze().detach().cpu()
vy_plot = vy_plot.squeeze().squeeze().detach().cpu()
plt.figure(figsize=(6, 5))
plt.subplot(2, 2, 1)
plt.scatter(X_plot.squeeze().detach().cpu(), Y_plot.squeeze().detach().cpu(), c=vx_plot, s = 1.5, cmap='jet')
plt.title('Ux')
plt.axis('equal')
plt.axis('off')
plt.colorbar(fraction=0.046, pad=0.04)
plt.subplot(2, 2, 2)
plt.scatter(X_plot.squeeze().detach().cpu(), Y_plot.squeeze().detach().cpu(), c=vy_plot, s = 1.5, cmap='jet')
plt.title('Uy')
plt.axis('equal')
plt.axis('off')
plt.colorbar(fraction=0.046, pad=0.04)
plt.tight_layout()
plt.show()